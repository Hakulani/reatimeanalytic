CREATE TABLE food_raw (
    id           SERIAL PRIMARY KEY,
    title        VARCHAR(120)
);

INSERT INTO food_raw (title) values ('Stranger Things');
INSERT INTO food_raw (title) values ('Black Mirror');
INSERT INTO food_raw (title) values ('The Office');